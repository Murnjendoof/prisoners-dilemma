
/**
 * The prisoner's dilemma
 *
 * @author Solomon Emet
 * @version 25/8/2021
 */

//keyboard
import java.util.Scanner;

//random number generator
import java.util.Random;

public class theGame
{
    //for keyboard reading
    String command;
    
    //setting up variables
    public boolean noDontGo = true;
    
    public int rounds = 0;
    
    public int youScore = 0;
    
    public int theyScore = 0;
    
    public int numClamups = 0;
    
    public int numSnitches = 0;
    
    public int actions[] = new int[6];
    
    public int theyWhat = 0;
    
    //for keyboard reading
    Scanner keyboard = new Scanner(System.in);
    
    //for random number generation
    Random random = new Random();
    
    /**
     * Constructor for objects of class theGame
     */
    public theGame()
    {
        //intro text
        System.out.println("You've been arrested for tax evasion.");
        System.out.println("Fortunately for you, the cops only have enough evidence to put you away for littering.");
        System.out.println("Even so, it's enough to put you away for two years.");
        System.out.println("The cops are interrogating you and your accomplice seperately.");
        System.out.println("If you both keep quiet, you'll both get the short sentence.");
        System.out.println("If you both snitch on each other, you'll both get a huge honkin' sentence.");
        System.out.println("But if you snitch, and your accomplice keeps quiet, the cops will let you go free while giving your buddy life.");
        System.out.println("And if you keep quiet, but your accomplice snitches, they'll go free and you'll get life.");
        System.out.println("This is the prisoner's dilemma.");
        System.out.println();
        //noDontGo is always true, until the player types "quit" in the below loop
        //ending the loop ends the program
        //it's set up in a loop like this so that people can play multiple games without having to open the program each time
        while(noDontGo){
            //more intsruction text
            System.out.println("How many rounds do you want to play?");
            System.out.println("(If you want to play a random number of rounds, type \"random\".)");
            System.out.println("(Or, if you want to quit, type \"quit\".)");
            //this makes the commands non-case-sensetive and stores them in a variable
            command = keyboard.nextLine().toLowerCase();
            if(isNumeric(command) == true && !command.contains("-") && !command.contains(".")){
                //if the command is a number, turns it into an int and starts the game with it as the number of rounds
                rounds = Integer.parseInt(command);
                game();
            } else {
                switch(command){
                    case "random":
                    //setting the number of rounds to a random number
                    rounds = random.ints(1,(21)).findFirst().getAsInt();
                    game();
                    break;
                    
                    case "break out":
                    //easter egg, just for fun
                    //even though it's not very funny
                    System.out.println("You bust out of prison. Unfortunately, once you're out, your old habit takes over and you find yourself being arrested for tax evasion, along with an accomplice.");
                    break;
                    
                    case "quit":
                    //sets noDontGo to false, which ends the loop and by extension the program
                    System.out.println("Good riddance.");
                    noDontGo = false;
                    break;
                    
                    default:
                    //reminds the player of the acceptable inputs in case they've forgotten
                    System.out.println("That is neither a whole number nor the word \"random\". Keep trying, I'm sure you'll get there eventually.");
                    break;
                }
            }
        }
    }

    /**
     * I used this code from java2blog.com
     *
     * @It returns true if the string is a number
     */
    public static boolean isNumeric(String str) {
        //don't really know how it works, but it does
        return str != null && str.matches("[-+]?\\d*\\.?\\d+");
    }
    
    /**
     * This is the game
     *
     * @It's the entire game
     */
    public void game() {
        //resetting some key variables
        youScore = 0;
        
        theyScore = 0;
        
        numClamups = 0;
    
        numSnitches = 0;
        
        //yet more intsructional text
        System.out.println("Let's play!");
        System.out.println("If you both keep quiet, you'll both get one point. If you screw over your buddy, you'll get two points and they'll get negative five.");
        System.out.println("If your buddy screws you over, they'll get two points and you'll get negative five. If you screw each other over you both get negative three.");
        System.out.println("Also, the computer will learn from your actions in intentionally unspecified ways.");
        System.out.println("The game will run for an unspecified number of rounds. Whoever has the most points at the end will win.");
        //runs this loop for the number of rounds as specified before the game began
        for(int i = 0; i < rounds; i++){
            System.out.println("Do you want to snitch or keep quiet?");
            System.out.println("(Type \"snitch\" or \"s\" to snitch and \"clamup\" or \"c\" to keep quiet.)");
            //makes commands non-case-sensetive
            command = keyboard.nextLine().toLowerCase();
            switch(command){
                case "snitch":
                
                case "s":
                //action is where most of the game happens, and the 1 is just to tell action that the player snitched
                action(1);
                break;
                
                case "clamup":
                
                case "c":
                //action is where most of the game happens, and the 2 is just to tell action that the player clammed up
                action(2);
                break;
                
                case "quit":
                
                case "q":
                //sets i to the number of rounds, which ends the game immediately
                System.out.println("You decide to use that phone call that they gave you. You call your lawyer, and he's able to make the cops stop interrogating you.");
                i = rounds;
                break;
                
                default:
                //reminds the player, rather bluntly, of the acceptable commands
                System.out.println("That's neither \"snitch\" nor \"s\" nor \"clamup\" nor \"c\". Are you dumb?");
                //sets the counter back one because otherwise the game would think a round had passed with no changes to the scores
                i--;
                break;
            }
        }
        //showing the scores
        //the years are just the scores subtracted from zero, because the more points you have, the lighter of a sentence you'll get
        //sometimes the game will say you're being put away for a negative number of years, which I left in because it's a pretty ridiculous concept, and that makes it kind of funny
        System.out.println("The cops are done interrogating you. In the end, they got enough evidence to put you away for " + (0 - youScore) + " year(s), and your buddy for " + (0 - theyScore) + " year(s).");
        //tells you whether you win, lose, or tied.
        if(youScore > theyScore){
            System.out.println("You win.");
        } else {
            if(youScore < theyScore){
                System.out.println("You lose.");
            } else {
                System.out.println("You tied. Somehow.");
            }
        }
        //leaves a gap before the main loop starts up again
        System.out.println();
    }
    
    /**
     * This allows the computer to track the player's actions
     *
     * @It tracks the player's actions and decides the outcome of rounds
     */
    public void action(int what) {
        //showing what you did, and starting to show what your opponent did
        System.out.print("You ");
        if(what == 1){
            System.out.print("snitched");
        } else {
            System.out.print("kept your mouth shut");
        }
        System.out.print(", and your buddy ");
        
        //resets these variables so that the next bit of code works
        numClamups = 0;
        numSnitches = 0;
        
        //this loop sets each piece of "actions[]" to the value of the piece above it
        //it then takes the value of "actions[i]" which is either a 0, 1, or 2 (0 being nothing, 1 being a snitch, and 2 being a clamup)
        //if the number at actions[i] isn't 0, it adds "i + 1" to the appropriate variable, either numSnitches or numClamups
        //(it adds "i + 1" because otherwise the action stored at "actions[0]" would never affect anything)
        for(int i = 0;i < 5;i++){
            if(actions[i] == 0){
                actions[i] = actions[i + 1];
                if(actions[i] == 1){
                    numSnitches += (i + 1);
                } else if (actions[i] == 2){
                    numClamups += (i + 1);
                }
            }
        }
        
        //if numSnitches is more than numClamups, theyWhat is set to 1
        //if numSnitches is less than numClamups, theyWhat is set to 2
        //if they're equal, theyWhat is randomly set to either 1 or 2
        if(numSnitches > numClamups){
            theyWhat = 1;
        } else if(numSnitches < numClamups) {
            theyWhat = 2;
        } else {
            theyWhat = random.ints(1,(3)).findFirst().getAsInt();
        }
        
        //this script just takes "theyWhat", compares it to "what", and prints out the appropriate outcome, along with changing the scores accordingly
        switch(theyWhat){
            case 1:
            if(what == 1){
                System.out.println("snitched too.");
                youScore -= 3;
                theyScore -= 3;
            } else {
                System.out.println("snitched. What a jerk.");
                youScore -= 5;
                theyScore += 2;
            }
            break;
            
            case 2:
            if(what == 1){
                System.out.println("kept his mouth shut. You jerk.");
                youScore += 2;
                theyScore -= 5;
            } else {
                System.out.println("kept quiet too. How nice.");
                youScore += 1;
                theyScore += 1;
            }
            break;
            
            default:
            //if this somehow happens, the game is ruined anyway, so your sentences become enormous just for fun, and you get an ominous message
            System.out.println("Something has gone horribly wrong.");
            youScore *= youScore;
            theyScore *= theyScore;
            break;
        }
        
        //finally, this sets "actions[5]" to whatever the player did this round, then starts the next round
        //it's done at the end so that the computer player never sees what the player did on the current round before it decides what it does
        actions[5] = what;
    }
}
